
## Problem statement

A common problem in Information Retrieval (IR) is to generate a term frequency matrix for a given corpus. This is used to retreive documents in a corpus against a given search term. In this exercise, we intend to build a matrix of the category frequencies of terms in a corpus of text messages.

## Requirements

* Python interpreter
* pip to install any required packages.
